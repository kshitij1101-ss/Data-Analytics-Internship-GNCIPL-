# GNCIPL Data Analytics Dashboard

A Streamlit dashboard for the GNCIPL data analytics internship project.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Push `app.py` and `requirements.txt` to your GitHub repository.
2. Open Streamlit Community Cloud.
3. Select the repository and branch.
4. Set the main file to `app.py`.
5. Click Deploy.

## Dataset

Place CSV/Excel files in the repository root or in a `data`, `dataset`, or `datasets` folder. The app automatically detects CSV/Excel files, or users can upload one from the sidebar.
